#!/usr/bin/python3
# 2019.11.12
# Author Zhang Yihao @NUS

import json
import numpy as np
from collections import defaultdict

dataName = "Sports"
iu_dict = defaultdict(list)
ui_dict = defaultdict(list)
reviews_data = []
train_list = []

num_items = 1  # 从1开始对用户进行编号
with open('../inputData/reviews_' + dataName) as f:
    for line in f:
        line_dict = json.dumps(eval(line))
        reviews_data.append(json.loads(line_dict))
        num_items += 1
    f.close()

'''建立ID和Num的对应关系 '''
asin2itemNum = {}
reviewerID2userNum = {}
num = 1
for ui in reviews_data:
    if ui["asin"] not in asin2itemNum:
        asin2itemNum[ui["asin"]] = num
        num += 1
num = 1
for uu in reviews_data:
    if uu["reviewerID"] not in reviewerID2userNum:
        reviewerID2userNum[uu["reviewerID"]] = num
        num += 1

# loading_user_items
for d in reviews_data:
    user_id = reviewerID2userNum.get(d["reviewerID"])
    item_id = asin2itemNum.get(d["asin"])
    if user_id not in ui_dict:
        ui_dict[user_id] = list()
    ui_dict[user_id].append(item_id)
    if item_id not in iu_dict:
        iu_dict[item_id] = list()
    iu_dict[item_id].append(user_id)


def split_train_test_data():
    train_data = open('../outputData/' + dataName + ".rmse.train.rating", "w")
    test_data = open('../outputData/' + dataName + ".rmse.test.rating", "w")
    num = 0
    for d in reviews_data:
        user_id = reviewerID2userNum.get(d["reviewerID"])
        item_id = asin2itemNum.get(d["asin"])
        overall = int(d["overall"])
        str_line = str(user_id) + "\t" + str(item_id) + "\t" + str(overall)
        if (num % 2) == 0:
            train_data.writelines(str_line + "\n")
        else:
            test_data.writelines(str_line + "\n")
        num += 1
    train_data.close()
    test_data.close()


def get_train_data():
    for d_line in reviews_data:
        user_id = reviewerID2userNum.get(d_line["reviewerID"])
        item_id = asin2itemNum.get(d_line["asin"])
        # uiPair = "[" + str(user_id) + " " + str(item_id) + "]"
        ui_array = np.array([user_id, item_id])
        train_list.append(ui_array)
    return train_list


def get_test_data():
    test_data = {}
    t_num = 0
    for d_item in reviews_data:
        u_num = asin2itemNum.get(d_item["asin"].strip("\n"))
        ui_link = ui_dict[u_num]
        str_num_pos = str(u_num) + "," + str(ui_link)
        tup_num_pos = tuple(eval(str_num_pos))
        if ui_link != '':
            test_data[t_num] = tup_num_pos
            t_num += 1
    return test_data


if __name__ == '__main__':
    split_train_test_data()
    train_list = get_train_data()
    test_dict = get_test_data()
    num_negatives = 100  # 构建num_negatives的个数
    '''保存数据为npz格式'''
    np.savez("../outputData/uiRating.npz", train_data=np.array(train_list), test_data=np.array(test_dict))
